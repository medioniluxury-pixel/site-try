
import React, { useEffect, useMemo, useState } from "react";

const LS_KEY = "vip_lead_qualifier_submissions_v1";
const initialForm = { companyName:"", contactName:"", contactEmail:"", website:"", location:"",
  desiredMarket:"Local", product:"", usp:"", sector:"", icp:"", priorEngagement:"None",
  priorEngagementNotes:"", eventsExperience:"", goal:[], monthlyBudget:"", timeline:"This Quarter",
  partnershipInterests:["VIP Engagement","Events"], notes:"" };
const GOAL_OPTIONS = ["Product Launch","New User Signups","Brand Awareness","Retail Sell-through","Lead Generation","Event Presence","Influencer/Celebrity Activation","Partnership Development"];
const INTEREST_OPTIONS = ["VIP Engagement","Strategic Partnerships","Events","Marketing Campaign","Brand Development"];

function scoreLead(v){let s=0;const b=Number(v.monthlyBudget||0);
  if(b>=100000)s+=35;else if(b>=50000)s+=28;else if(b>=25000)s+=22;else if(b>=10000)s+=15;else if(b>=5000)s+=8;else if(b>0)s+=4;
  if(v.desiredMarket==="Nationwide")s+=10; if(v.desiredMarket==="Multi-Region")s+=7;
  if(v.priorEngagement==="Sports/Celebrity")s+=12; else if(v.priorEngagement==="Events")s+=8;
  if((v.icp||"").length>=80)s+=12; else if((v.icp||"").length>=40)s+=8; else if((v.icp||"").length>=15)s+=5;
  const aligned=(v.goal||[]).filter(g=>["Product Launch","New User Signups","Brand Awareness","Partnership Development","Influencer/Celebrity Activation","Event Presence"].includes(g)).length; s+=Math.min(12,aligned*3);
  const desired=(v.partnershipInterests||[]).filter(i=>["VIP Engagement","Strategic Partnerships","Events","Marketing Campaign","Brand Development"].includes(i)).length; s+=Math.min(12,desired*3);
  if(v.timeline==="ASAP")s+=9; else if(v.timeline==="This Quarter")s+=6;
  if((v.usp||"").length>=60)s+=8; else if((v.usp||"").length>=25)s+=5;
  return Math.min(100,s);
}
function pctColor(p){if(p>=80)return "bg-green-500"; if(p>=60)return "bg-emerald-400"; if(p>=40)return "bg-yellow-400"; if(p>=20)return "bg-orange-400"; return "bg-red-400";}
const Badge=({children})=>(<span className="inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium bg-white/60 border-gray-200 text-gray-700">{children}</span>);
const Section=({title,subtitle,children})=>(<section className="bg-white rounded-2xl shadow-sm border border-gray-100 p-5 md:p-6"><div className="mb-3"><h3 className="text-lg font-semibold text-gray-900">{title}</h3>{subtitle&&<p className="text-sm text-gray-500 mt-1">{subtitle}</p>}</div>{children}</section>);
const Input=({label,required,...props})=>(<label className="block"><span className="block text-sm font-medium text-gray-700 mb-1">{label} {required&&<span className="text-red-500">*</span>}</span><input {...props} className={`w-full rounded-xl border border-gray-300 bg-white px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-black/50 focus:border-black/50 ${props.className||""}`}/></label>);
const TextArea=({label,required,...props})=>(<label className="block"><span className="block text-sm font-medium text-gray-700 mb-1">{label} {required&&<span className="text-red-500">*</span>}</span><textarea {...props} className={`w-full min-h-[90px] rounded-xl border border-gray-300 bg-white px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-black/50 focus:border-black/50 ${props.className||""}`}/></label>);
const Select=({label,options,required,value,onChange,multiple})=>(<label className="block"><span className="block text-sm font-medium text-gray-700 mb-1">{label} {required&&<span className="text-red-500">*</span>}</span><select value={value} multiple={multiple} onChange={onChange} className="w-full rounded-xl border border-gray-300 bg-white px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-black/50 focus:border-black/50">{!multiple&&<option value="">Select…</option>}{options.map(o=><option key={o} value={o}>{o}</option>)}</select></label>);
function ToggleChips({label,options,values,setValues}){return(<div><span className="block text-sm font-medium text-gray-700 mb-1">{label}</span><div className="flex flex-wrap gap-2">{options.map(opt=>{const active=values.includes(opt);return(<button type="button" key={opt} onClick={()=>setValues(prev=>prev.includes(opt)?prev.filter(v=>v!==opt):[...prev,opt])} className={`px-3 py-1.5 rounded-full text-sm border transition ${active?"bg-black text-white border-black":"bg-white text-gray-700 border-gray-300 hover:border-gray-400"}`}>{opt}</button>)})}</div></div>);}
const Progress=({value})=>(<div className="w-full h-3 bg-gray-100 rounded-full overflow-hidden"><div className={`h-full ${pctColor(value)} transition-all`} style={{width:`${value}%`}}/></div>);

function SubmissionsTable({data,onDelete,onExport}){return(<Section title="Submissions" subtitle="Qualified leads saved in your browser (localStorage)."><div className="flex items-center justify-between mb-3"><div className="text-sm text-gray-600">{data.length} record(s)</div><div className="flex gap-2"><button onClick={onExport} className="px-3 py-2 rounded-xl border text-sm hover:bg-gray-50">Export CSV</button><button onClick={onDelete} className="px-3 py-2 rounded-xl border text-sm hover:bg-gray-50">Clear All</button></div></div><div className="overflow-x-auto"><table className="min-w-full text-sm"><thead><tr className="text-left border-b"><th className="py-2 pr-4">Score</th><th className="py-2 pr-4">Company</th><th className="py-2 pr-4">Contact</th><th className="py-2 pr-4">Market</th><th className="py-2 pr-4">Budget ($/mo)</th><th className="py-2 pr-4">Goals</th><th className="py-2 pr-4">Interests</th></tr></thead><tbody>{data.map((row,idx)=>(<tr key={idx} className="border-b hover:bg-gray-50"><td className="py-2 pr-4"><div className="flex items-center gap-2"><Badge>{row.score}</Badge><div className="w-24"><Progress value={row.score}/></div></div></td><td className="py-2 pr-4"><div className="font-medium">{row.companyName}</div><div className="text-xs text-gray-500">{row.location}</div></td><td className="py-2 pr-4"><div>{row.contactName}</div><div className="text-xs text-gray-500">{row.contactEmail}</div></td><td className="py-2 pr-4">{row.desiredMarket}</td><td className="py-2 pr-4">{row.monthlyBudget}</td><td className="py-2 pr-4">{(row.goal||[]).join(", ")}</td><td className="py-2 pr-4">{(row.partnershipInterests||[]).join(", ")}</td></tr>))}</tbody></table></div></Section>);}

export default function App(){const [form,setForm]=useState(initialForm);const [submissions,setSubmissions]=useState([]);const [showSummary,setShowSummary]=useState(false);
useEffect(()=>{const raw=localStorage.getItem(LS_KEY);if(raw){try{setSubmissions(JSON.parse(raw))}catch{}}},[]);
useEffect(()=>{localStorage.setItem(LS_KEY,JSON.stringify(submissions))},[submissions]);
const score=useMemo(()=>scoreLead(form),[form]); const tier=score>=80?"A (High Priority)":score>=60?"B (Strong Fit)":score>=40?"C (Nurture)":score>=20?"D (Explore)":"E (Archive)";
function handleChange(e){const {name,value}=e.target; setForm(f=>({...f,[name]:value}))}
function handleMultiChange(key,e){const selected=Array.from(e.target.selectedOptions).map(o=>o.value); setForm(f=>({...f,[key]:selected}))}
function downloadCSV(){if(!submissions.length)return; const headers=Object.keys({...initialForm,score:0,tier:""}); const rows=submissions.map(s=>({...initialForm,...s})); const csv=[headers.join(",")].concat(rows.map(r=>headers.map(h=>{const v=Array.isArray(r[h])?r[h].join("|"):r[h]??""; return "\""+str(v:=str(v).replace('"','""'))+"\""}).join(","))).join("\n"); const blob=new Blob([csv],{type:"text/csv;charset=utf-8;"}); const url=URL.createObjectURL(blob); const a=document.createElement("a"); a.href=url; a.download=`vip_leads_${new Date().toISOString().slice(0,10)}.csv`; a.click(); URL.revokeObjectURL(url);}
function clearAll(){ if(confirm("Clear all stored submissions?")) setSubmissions([]) }
function handleSubmit(e){ e.preventDefault(); const payload={...form,score,tier,createdAt:new Date().toISOString()}; setSubmissions(rows=>[payload,...rows]); setShowSummary(true); setForm(f=>({...initialForm,desiredMarket:f.desiredMarket,partnershipInterests:f.partnershipInterests}))}
return(<div className="min-h-screen bg-gradient-to-b from-gray-50 to-white text-gray-900">
  <header className="bg-black text-white">
    <div className="max-w-6xl mx-auto px-5 pt-8 pb-6">
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <img src="/mlux-logo.png" alt="Medioni Luxury" className="h-12 w-auto object-contain" />
          <div>
            <div className="text-xl md:text-2xl font-bold tracking-tight">Medioni Luxury</div>
            <div className="text-xs md:text-sm text-white/70">VIP Engagement Strategy • Partnerships • Events • Marketing Campaigns • Brand Development</div>
          </div>
        </div>
        <div className="hidden md:block">
          <div className="px-4 py-2 rounded-xl border border-white/20 bg-white/5 text-sm">
            <div className="font-semibold">Lead Score</div>
            <div className="flex items-center gap-2 mt-1">
              <Badge>{score}</Badge>
              <div className="w-28"><Progress value={score} /></div>
            </div>
            <div className="text-xs text-white/70 mt-1">Tier: {tier}</div>
          </div>
        </div>
      </div>
    </div>
  </header>
  <main className="max-w-6xl mx-auto px-5 pb-20 grid grid-cols-1 md:grid-cols-3 gap-6">
    <form onSubmit={handleSubmit} className="md:col-span-2 space-y-6">
      <Section title="Company & Contacts">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input label="Company Name" name="companyName" required value={form.companyName} onChange={handleChange} />
          <Input label="Website" name="website" placeholder="https://" value={form.website} onChange={handleChange} />
          <Input label="Contact Name" name="contactName" value={form.contactName} onChange={handleChange} />
          <Input label="Contact Email" name="contactEmail" type="email" value={form.contactEmail} onChange={handleChange} />
          <Input label="Location (City, State/Country)" name="location" value={form.location} onChange={handleChange} />
          <Select label="Desired Market" value={form.desiredMarket} onChange={(e)=>setForm(f=>({...f,desiredMarket:e.target.value}))} options={["Local","Multi-Region","Nationwide"]} />
        </div>
      </Section>
      <Section title="Product & Positioning">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input label="Product / Offering" name="product" value={form.product} onChange={handleChange} />
          <Input label="Sector / Category" name="sector" placeholder="CPG, Apparel, Alcohol, Tech…" value={form.sector} onChange={handleChange} />
        </div>
        <div className="mt-4 grid grid-cols-1 gap-4">
          <TextArea label="Unique Selling Proposition (USP)" name="usp" value={form.usp} onChange={handleChange} />
          <TextArea label="Ideal Customer Profile (ICP)" name="icp" placeholder="Who do you sell to? Demographics, budget, channels, geographies, use‑cases…" value={form.icp} onChange={handleChange} />
        </div>
      </Section>
      <Section title="Marketing Goals & Experience">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Select label="Prior Engagement" value={form.priorEngagement} onChange={(e)=>setForm(f=>({...f,priorEngagement:e.target.value}))} options={["None","Events","Sports/Celebrity"]} />
          <Input label="Monthly Budget (USD)" name="monthlyBudget" type="number" min="0" step="100" placeholder="e.g., 25000" value={form.monthlyBudget} onChange={handleChange} />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          <TextArea label="If any, describe prior sports/celebrity or events engagement" name="priorEngagementNotes" value={form.priorEngagementNotes} onChange={handleChange} />
          <TextArea label="Events (past or desired)" name="eventsExperience" value={form.eventsExperience} onChange={handleChange} />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          <Select label="Primary Goals" multiple value={form.goal} onChange={(e)=>handleMultiChange('goal', e)} options={GOAL_OPTIONS} />
          <Select label="Timeline" value={form.timeline} onChange={(e)=>setForm(f=>({...f, timeline:e.target.value}))} options={["ASAP","This Quarter","This Year"]} />
        </div>
        <div className="mt-4">
          <ToggleChips label="Partnership Interests" options={INTEREST_OPTIONS} values={form.partnershipInterests} setValues={(vals)=>setForm(f=>({...f, partnershipInterests: vals}))} />
        </div>
        <div className="mt-4">
          <TextArea label="Notes" name="notes" value={form.notes} onChange={handleChange} />
        </div>
      </Section>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3"><Badge>Score: {score}</Badge><Badge>Tier: {tier}</Badge></div>
        <button type="submit" className="px-5 py-2.5 rounded-xl bg-black text-white font-medium shadow-sm hover:opacity-90">Save & Score Lead</button>
      </div>
    </form>
    <div className="space-y-6">
      <Section title="Live Scorecard" subtitle="Auto-updates as you type.">
        <div className="space-y-3">
          <div className="flex items-center gap-3">
            <div className="text-4xl font-bold">{score}</div>
            <div className="flex-1"><Progress value={score} /></div>
          </div>
          <div className="text-sm text-gray-600">Tier Recommendation: <span className="font-medium text-gray-900">{tier}</span></div>
          <div className="text-xs text-gray-500">Scoring considers budget, scope, prior engagement, ICP/USP clarity, goal & interest alignment, and timeline.</div>
        </div>
      </Section>
      <SubmissionsTable data={submissions} onDelete={clearAll} onExport={downloadCSV} />
    </div>
  </main>
  <footer className="bg-black text-white">
    <div className="max-w-6xl mx-auto px-5 pb-10 text-xs">
      <div className="border-t border-white/10 pt-4 flex items-center justify-between">
        <div>© {new Date().getFullYear()} Medioni Luxury</div>
        <div className="flex flex-wrap gap-2">{["VIP Engagement","Strategic Partnerships","Events","Marketing Campaigns","Brand Development"].map(x=>(<span key={x} className="inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium bg-white text-black border-white">{x}</span>))}</div>
      </div>
    </div>
  </footer>
</div>)};
