
# Medioni Luxury — VIP Lead & Partner Qualifier

Vite + React + Tailwind app with your logo wired in the header.

## Local
npm install
npm run dev

## Build
npm run build

## Deploy (Vercel)
- Import this repo into Vercel
- Framework: **Vite**
- Build: `npm run build`
- Output: `dist`
